﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    //-------------------attach this script to Player--------------------------------------
    public Rigidbody rb;
    public UIManager uiManager;
    public CameraBob camBob;

    public float moveSpeed = 5f;
    public float sprintSpeed = 7f;
    public float jumpForce = 4f;
    public float jumpRayDistance = 1.1f;

    [HideInInspector] public bool isSprinting;
    [HideInInspector] public bool isMoving;

    private float moveX;
    private float moveZ;
    private float baseMoveSpeed;
    private bool trySprinting;
    private bool tryJump;
    

    //our stored vectors for moving
    private Vector3 moveOutput;
    private Vector3 newPosition;

    private void Start()
    {
        baseMoveSpeed = moveSpeed;
    }
    private void Update()
    {
        if (!uiManager.inventoryIsActive)
        {
            //getting input in update so we dont miss any player input
            GetInput();

            //we can jump in update because it feels more responsive and not a huge issue like it is with moving around
            // i might be wrong so feel free to mess around with it
            Jump();
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!uiManager.inventoryIsActive)
        {
            //moving player in fixed update since we using physics 
            Move();
            Sprint();
        }
        if (uiManager.inventoryIsActive)
        {
            rb.constraints = RigidbodyConstraints.FreezeAll;
        }
        else
        {
            rb.constraints &= RigidbodyConstraints.FreezeRotationZ | RigidbodyConstraints.FreezeRotationX;
        }
    }

    void GetInput()
    {
        moveX = Input.GetAxisRaw("Horizontal");
        moveZ = Input.GetAxisRaw("Vertical");

        trySprinting = Input.GetKey(KeyCode.LeftShift);

        tryJump = Input.GetKeyDown(KeyCode.Space);
       
    }

    void Move()
    {
        //getting and storing the move output but not applying it yet
        moveOutput = new Vector3(moveX, 0, moveZ).normalized * moveSpeed * Time.fixedDeltaTime;

        //getting our new desired position by using our stored input
        newPosition = rb.position + rb.transform.TransformDirection(moveOutput);

        //actually moving the player
        rb.MovePosition(newPosition);

        if (moveX >= 0.1f || moveZ >= 0.1f)
            isMoving = true;
        else
            isMoving = false;
    }

    void Sprint()
    {
        if (isMoving == true)
        {
            if (trySprinting == true)
            {
                moveSpeed = sprintSpeed;
                isSprinting = true;
            }
            else
            {
                moveSpeed = baseMoveSpeed;
                isSprinting = false;
            }
        }
    }

    void Jump()
    {
        if (tryJump == true && IsGrounded() == true)
        {
            rb.AddForce(0, jumpForce, 0, ForceMode.Impulse);
            camBob.allowCamBob = false;
        }
        else
            camBob.allowCamBob = true;
    }

    private bool IsGrounded()
    {
        //returns true or false depending on if our raycast hits anything
        return Physics.Raycast(transform.position, Vector3.down, jumpRayDistance);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerInteraction : MonoBehaviour
{
    [Header("Interaction Properties")]
    public LayerMask interactionLayer;
    public float interactionDistance;

    private GameObject currentInteractable;

    [Header("item drop info")]
    public GameObject dropPoint;
    public float sphereRadius;
    public float maxCheckDistance;
    public LayerMask dropItemLayerMask;

    private float curHitDistance;
    private Vector3 orgin;
    private Vector3 direction;

    [Header("Interaction UI")]
    public TextMeshProUGUI interactionText;

    [Header("Refrences")]
    public UIManager uiManager;
    public Inventory inventory;
    private Interactable.InteractionType interactionType = Interactable.InteractionType.na;


    private void Start()
    {
        interactionText.text = "";
    }

    private void Update()
    {
        Interaction();
        SetDropLocation();
    }

    public void Interaction()
    {
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray,out hit,interactionDistance,interactionLayer))
        {
            if (hit.collider.gameObject.GetComponent<Interactable>())
            {
                currentInteractable = hit.collider.gameObject;
                this.interactionType = currentInteractable.GetComponentInChildren<Interactable>().interactionType;
                int interactableQuantity = hit.collider.gameObject.GetComponent<Interactable>().quantity;


                if (interactionType == Interactable.InteractionType.pickUp)
                {

                    GenerateInteractionText(interactionType);

                    if (Input.GetKeyDown(uiManager.interactionButton))
                    {
                        inventory.AddItem(currentInteractable.name,interactableQuantity);
                        currentInteractable.SetActive(false);
                        Destroy(currentInteractable);
                        currentInteractable = null;
                        interactionType = Interactable.InteractionType.na;
                    }
                }

                else if (interactionType == Interactable.InteractionType.harvest)
                {
                    GenerateInteractionText(interactionType);

                    if (Input.GetKeyDown(uiManager.interactionButton))
                    {
                        inventory.AddItem(currentInteractable.name, interactableQuantity);
                        currentInteractable.SetActive(false);
                        Destroy(currentInteractable);
                        currentInteractable = null;
                        interactionType = Interactable.InteractionType.na;
                    }
                }

                else if (interactionType == Interactable.InteractionType.ui)
                {
                    GenerateInteractionText(interactionType);

                    if (Input.GetKeyDown(uiManager.interactionButton))
                    {
                        //currentInteractable.SetActive(false);
                        //Destroy(currentInteractable);
                        //uiManager.OpenCraftBench();
                        //currentInteractable = null;
                        //interactionType = Interactable.InteractionType.na;
                        Debug.Log("no no no not yet");
                    }
                }

                else { return; }

            }
        }
        else
        {
            interactionType = Interactable.InteractionType.na;
            currentInteractable = null;
            GenerateInteractionText(interactionType);
            //uiManager.SetScreenOff(uiManager.craftingPanel);
        }
    }

    void GenerateInteractionText(Interactable.InteractionType type)
    {
        if (type == Interactable.InteractionType.na)
        {
            interactionText.text = " ";
            uiManager.SetScreenOff(uiManager.interactionScreen);
        }
        else
        {
            if (type == Interactable.InteractionType.pickUp)
            {
                uiManager.SetScreenOn(uiManager.interactionScreen);
                interactionText.text = "Pick Up: (E) " + currentInteractable.name.ToString();
            }
            else if (type == Interactable.InteractionType.harvest)
            {
                uiManager.SetScreenOn(uiManager.interactionScreen);
                interactionText.text = "Havest: (E) " + currentInteractable.name.ToString();
            }
            else if (type == Interactable.InteractionType.ui)
            {
                uiManager.SetScreenOn(uiManager.interactionScreen);
                interactionText.text = "Open: (E) " + currentInteractable.name.ToString();
            }
        }
    }


    public void SetDropLocation()
    {
        RaycastHit dropHitSphere;
        RaycastHit dropHitRay;

        orgin = transform.position;
        direction = transform.forward;

        if (Physics.SphereCast(orgin,sphereRadius,direction,out dropHitSphere,maxCheckDistance,dropItemLayerMask,QueryTriggerInteraction.UseGlobal))
        {
            dropPoint.transform.position = dropHitSphere.transform.position;
            curHitDistance = dropHitSphere.distance;
        }
        else
        {
            curHitDistance = maxCheckDistance;
            Ray dropRay = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(dropRay, out dropHitRay, maxCheckDistance, dropItemLayerMask))
            {
                dropPoint.transform.position = dropHitRay.point;
                dropPoint.transform.rotation = Quaternion.identity;

            }
        }

    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Debug.DrawLine(orgin, orgin + direction * curHitDistance);
        Gizmos.DrawWireSphere(orgin + direction * curHitDistance, sphereRadius);

    }
}

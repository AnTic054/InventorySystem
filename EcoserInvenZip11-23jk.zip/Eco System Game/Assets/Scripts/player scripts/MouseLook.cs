﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseLook : MonoBehaviour
{
    //-------------------attach this script to player camera--------------------------------------
    //make camera child of player obj and set pos to whatever looks best
    public float lookSensetivity = 2;
    public float smoothing = 2;

    public UIManager uiManager;

    private GameObject player;
    private Vector2 smoothedVelocity;
    private Vector2 currentLookPos;

    // Start is called before the first frame update
    void Start()
    {
        player = transform.parent.gameObject;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Update()
    {
        if (!uiManager.inventoryIsActive)
        {
            CamLook();
        }
    }

    void CamLook()
    {
        //Getting the mouse Input
        Vector2 inputValues = new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y"));

        //scales our input values to make them more usable
        inputValues = Vector2.Scale(inputValues, new Vector2(lookSensetivity * smoothing, lookSensetivity * smoothing));

        //smoothing our camera so it feels better and doesnt just snao everywhere
        smoothedVelocity.x = Mathf.Lerp(smoothedVelocity.x, inputValues.x, 1f / smoothing);
        smoothedVelocity.y = Mathf.Lerp(smoothedVelocity.y, inputValues.y, 1f / smoothing);

        currentLookPos += smoothedVelocity;
        //rotating our camera independant of player on y axis
        transform.localRotation = Quaternion.AngleAxis(-currentLookPos.y, Vector3.right);

        //rotating our player with our cameras look position on the x axis
        player.transform.localRotation = Quaternion.AngleAxis(currentLookPos.x, player.transform.up);

        //clamping our up and down look so we cant just spin all the way around ourselves
        currentLookPos.y = Mathf.Clamp(currentLookPos.y, -80f, 80f);
    }
}

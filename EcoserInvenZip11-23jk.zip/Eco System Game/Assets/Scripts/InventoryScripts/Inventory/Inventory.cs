﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Inventory : MonoBehaviour
{
    public Dictionary<Item, int> iItems = new Dictionary<Item, int>();
    ItemDatabase itemDatabase;
    //public UIItem uiItem;

    [SerializeField] private UIInventory uiInventory;

    public SlotPanel invenSlotPanel;

    private void Awake()
    {
        itemDatabase = FindObjectOfType<ItemDatabase>();
    }

    private void Start()
    {
        AddItem(1,3);
        AddItem(2,2);
        AddItem(1,3);
        AddItem(1,2);
        AddItem(2,3);
    }

    public void AddItem(int id,int quantity)
    {
        Item itemToAdd = itemDatabase.GetItem(id);

            if (iItems.ContainsKey(itemToAdd))
            {
                itemToAdd.quantity += quantity;
                iItems[itemToAdd] = itemToAdd.quantity;
            }
            else
            {
                itemToAdd.quantity += quantity;
                iItems.Add(itemToAdd, quantity);
                uiInventory.AddItemToUI(itemToAdd);
            }
    }

    public void AddItem(string itemName,int quantity)
    {
        Item itemToAdd = itemDatabase.GetItem(itemName);

        if (iItems.ContainsKey(itemToAdd))
        {
            itemToAdd.quantity += quantity;
            iItems[itemToAdd] = itemToAdd.quantity;
            Debug.Log(iItems[itemToAdd]);
        }
        else
        {
            itemToAdd.quantity += quantity;
            iItems.Add(itemToAdd, quantity);
            uiInventory.AddItemToUI(itemToAdd);
        }
    }


    public void RemoveItem(Item item)
    {
            if (iItems.ContainsKey(item))
            {
                iItems.Remove(item);
                invenSlotPanel.RemoveItem(item);
            }
    }

    // ---------------- needs re-work -------------

    /*
    public Item CheckForItem(int id)
    {
        return inventoryItems.Find(item => item.ID == id);
    }
    public Item CheckForItem(string name)
    {
        return inventoryItems.Find(item => item.name == name);
    }
    */
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;
using System.Linq;

public class UIItem : MonoBehaviour,IPointerDownHandler,IPointerEnterHandler,IPointerExitHandler
{

    public Item item;

    private Image spriteImage;
    private UIItem selectedItem;
    private CraftingSlots craftingSlots;
    private ToolTip toolTip;
    public TextMeshProUGUI quantityText;

    private Inventory playerInven;
    private PlayerInteraction playerInteraction;

    public bool craftingSlot = false;
    public bool craftingResultSlot = false;


    private void Awake()
    {

        toolTip = FindObjectOfType<ToolTip>();
        craftingSlots = FindObjectOfType<CraftingSlots>();
        selectedItem = GameObject.Find("SelectedItem").GetComponent<UIItem>();
        spriteImage = GetComponent<Image>();
        UpdateItem(null);

        playerInven = GameObject.Find("Player").GetComponent<Inventory>();
        playerInteraction = GameObject.Find("Player").GetComponent<PlayerInteraction>();

    }

    private void Update()
    {
        UpdateItem(item);
    }

    public void UpdateItem(Item item)
    {
        this.item = item;

        if (this.item != null)
        {
            spriteImage.color = Color.white;
            spriteImage.sprite = item.icon;
            if (quantityText != null)
            {
                quantityText.text = item.quantity.ToString();
            }
        }
        else if (this.item == null || this.item.quantity == 0)
        {
            spriteImage.color = Color.clear;
            if (quantityText != null)
            {

            quantityText.text = "";
            }
        }

        if (craftingSlot)
        {
            craftingSlots.UpdateRecipe();
            if (quantityText != null && this.item != null)
            {
                quantityText.text = item.quantity.ToString();
            }
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {

        if (this.item != null)
        {
            GameObject prefab = item.itemPrefab;

            if (eventData.button == PointerEventData.InputButton.Left)
            {

                UICraftResult craftResult = GetComponent<UICraftResult>();
                if (craftResult != null && this.item != null && selectedItem.item == null)
                {
                    craftResult.PickItem();
                    selectedItem.UpdateItem(this.item);
                    craftResult.ClearSlots();
                    ClearQuantityText();
                    UpdateQuantityText();
                }
                else if (!craftingResultSlot)
                {
                    if (selectedItem.item != null)
                    {
                        Item clone = new Item(selectedItem.item);
                        selectedItem.UpdateItem(this.item);
                        UpdateItem(clone);
                        ClearQuantityText();
                        UpdateQuantityText();

                    }
                    else
                    {
                        selectedItem.UpdateItem(this.item);
                        UpdateItem(null);
                        ClearQuantityText();
                        UpdateQuantityText();
                    }
                }
            }

            if (eventData.button == PointerEventData.InputButton.Right)
            {
                if (item.quantity > 1)
                {
                    Vector3 dropPoint = playerInteraction.dropPoint.transform.position;

                    GameObject newPrefab = (GameObject)Instantiate(prefab, new Vector3(dropPoint.x, dropPoint.y, dropPoint.z - .5f), Quaternion.identity);
                    newPrefab.name = prefab.name;


                    UpdateItem(this.item);
                    ClearQuantityText();
                    UpdateQuantityText();


                    item.quantity--;
                }
                    else
                    {
                        Vector3 dropPoint = playerInteraction.dropPoint.transform.position;

                        GameObject newPrefab = (GameObject)Instantiate(prefab, new Vector3(dropPoint.x, dropPoint.y, dropPoint.z - 1f), Quaternion.identity);
                        newPrefab.name = prefab.name;

                        item.quantity--;

                        ClearQuantityText();
                        UpdateQuantityText();
                        playerInven.RemoveItem(item);
                        UpdateItem(null);
                        item = null;

                    }
            }
        }

            else if (selectedItem.item != null && !craftingResultSlot && eventData.button == PointerEventData.InputButton.Left)
            {
                UpdateItem(selectedItem.item);
                selectedItem.UpdateItem(null);
                ClearQuantityText();
                UpdateQuantityText();
            }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (this.item != null)
        {
            toolTip.GenerateToolTipText(item);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        toolTip.gameObject.SetActive(false);
    }


    public void ClearQuantityText()
    {
        if (this.item == null)
        {
            quantityText.text = " ";
        }
    }

    public void UpdateQuantityText()
    {
        if (this.item != null)
        {
            quantityText.text = item.quantity.ToString();
        }
    }

}

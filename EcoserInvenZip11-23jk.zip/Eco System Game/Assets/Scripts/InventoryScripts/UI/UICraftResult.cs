﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class UICraftResult : MonoBehaviour
{
    public SlotPanel slotPanel;
    public Inventory inventory;


    public void PickItem()
    {
        inventory.iItems.Add(GetComponent<UIItem>().item, GetComponent<UIItem>().item.quantity);
    }

    public void ClearSlots()
    {
        slotPanel.EmptyAllSlots();
    }
}

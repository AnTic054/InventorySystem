﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Item
{

    public int quantity;
    public GameObject itemPrefab;

    public int ID;
    public string name = "my new item";
    public string description = "my item description";
    public Sprite icon;
    public Dictionary<string, int> stats = new Dictionary<string, int>();

    public Item(int id,string title,int quantity,string description,Dictionary<string,int> stats)
    {
        this.ID = id;
        this.name = title;
        this.quantity = quantity;
        this.description = description;
        this.icon = Resources.Load<Sprite>("Items/Sprites/" + name);
        this.itemPrefab = Resources.Load<GameObject>("Items/itemPrefabs/" + name);
        this.stats = stats;
    }

    public Item(Item item)
    {
        this.ID = item.ID;
        this.name = item.name;
        this.description = item.description;
        this.icon = item.icon;
        this.stats = item.stats;
        this.quantity = item.quantity;
        this.itemPrefab = item.itemPrefab;
    }
}

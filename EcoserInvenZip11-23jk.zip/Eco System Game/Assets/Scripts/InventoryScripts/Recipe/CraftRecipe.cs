﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraftRecipe
{
    public enum Type
    {
        Consumable,
        Tool,
        Weapon,
        Raw_Material
    }

    public int[] requiredItems;
    public int itemToCraftID;
    public int quantity = 1;
    public Type type;

    public CraftRecipe(int itemToCraftID,int quantity,int[] requiredItems)
    {
        this.requiredItems = requiredItems;
        this.itemToCraftID = itemToCraftID;
        this.quantity = quantity;
    }
}

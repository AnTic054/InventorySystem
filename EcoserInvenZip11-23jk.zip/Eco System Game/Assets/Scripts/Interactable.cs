﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interactable : MonoBehaviour
{
    public enum InteractionType
    {
        na,
        pickUp,
        harvest,
        ui
    }

    public InteractionType interactionType;
    public int quantity = 1;
}

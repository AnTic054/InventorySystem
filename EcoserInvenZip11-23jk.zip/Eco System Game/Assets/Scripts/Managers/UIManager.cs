﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    [Header("Screens")]
    public GameObject inventoryScreen;
    public GameObject interactionScreen;
    public GameObject craftingPanel;

    [Header("Inputs")]
    public KeyCode inventoryButton;
    public KeyCode interactionButton;

    [Header("Screen Bools")]
    public bool inventoryIsActive = false;

    private void Update()
    {
        InventorySetter();
    }

    void InventorySetter()
    {
        if (Input.GetKeyDown(inventoryButton) && inventoryIsActive == false)
        {
            SetScreenOn(inventoryScreen);
            inventoryIsActive = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        else if (Input.GetKeyDown(inventoryButton) && inventoryIsActive == true)
        {
            SetScreenOff(inventoryScreen);
            inventoryIsActive = false;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
    }

    public void SetScreenOn(GameObject screen)
    {
        screen.SetActive(true);
    }

    public void SetScreenOff(GameObject screen)
    {
        screen.SetActive(false);
    }


    public void OpenCraftBench()
    {
        craftingPanel.SetActive(true);
        inventoryScreen.SetActive(true);
    }
}
